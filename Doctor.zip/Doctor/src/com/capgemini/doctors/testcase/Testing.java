package com.capgemini.doctors.testcase;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.doctors.Exception.DoctorAppointmentException;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exception.AppointmentException;


public class Testing {
	IDoctorAppointmentDao damo;
	private int appointmentId;
	
	@Before
	public void beforeMethod(){
	damo=new DoctorAppointmentDao();	
	}
	@Test
	public void testAddDoctorAppointmentDetails(){
		DoctorAppointment d=new DoctorAppointment();
		d.setPatientName("Mrudula");;
		d.setPhoneNumber("7032828699");
		d.setDateOfAppointment(LocalDate.of(2019, 01, 26));
		d.setEmail("sony@gmail.com");
		d.setAge(21);
		d.setGender("Femaile");
		d.setProblemName("Heart");
		d.setDoctorName("Kanika Kapoor");
		d.setAppointmentStatus("APPROVED");
		try{
			assertNotNull(dao.addDoctorAppointmentDetails(d));
		}catch(DoctorAppointmentException e){
			e.printStackTrace();
		}
	}	
		
}

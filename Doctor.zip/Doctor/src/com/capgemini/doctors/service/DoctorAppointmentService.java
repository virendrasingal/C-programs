package com.capgemini.doctors.service;

import java.util.List;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exception.AppointmentException;



public class DoctorAppointmentService implements IDoctorAppointmentService {

	IDoctorAppointmentDao rdao = new DoctorAppointmentDao();
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment)
			throws AppointmentException {
		
		return rdao.addDoctorAppointmentDetails(doctorAppointment);
	}

	@Override
	public List<DoctorAppointment> getDoctorAppointmentDetails(int appointmentId)
			throws AppointmentException {

		return rdao.getAppointmentDetails(appointmentId);
	}

	@Override
	public boolean validateDoctorAppointmentDetails(DoctorAppointment doctorAppointment) 
			throws AppointmentException {
		if(!doctorAppointment.getProblemName().matches("[A-Z]{3}[a-z]{10}")){
			throw new AppointmentException("Problem name should have and start with capital letters");
		}
		if(!doctorAppointment.getPatientName().matches("[A-Z]{1}[a-z]{10}")){
			throw new AppointmentException("Problem name should start with capital letter");
		}
		if(!doctorAppointment.getEmail().matches(".*@.*.com")){
			throw new AppointmentException("Enter valid Email Id ");
		}
		if(!doctorAppointment.getPhoneNumber().matches("[0-9]{10}")){
			throw new AppointmentException("Phone number should be of 10 digidts");
		}
		if(!doctorAppointment.getAge().matches("[0-9]{2}")){
			throw new AppointmentException("Age should be of 2 digidts");
		}
		return true;
	}

}
